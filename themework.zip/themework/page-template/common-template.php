<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Template Name: Common Page Template
 *
 *
 */
get_header();

?>

<section class="page-content">
	
<?php
       // Start the loop.
       while ( have_posts() ) : the_post();
       the_content();

       // End the loop.
       endwhile;
    ?>    
   
</section>


<?php 
get_footer(); 
?>
