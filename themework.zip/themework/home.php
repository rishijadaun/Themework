<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
get_header();
?>
  <div class="ranking_page_banner">
	  	  <div class="container">
	        <h1 class="text-white display-2"><?php the_title() ?></h1>
	   </div>
	 </div>
<section class="blogpage site-content">
<div class="container">
	<div class="row content-row">
  <!-- Start the Loop. -->
 <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

 <div class="post col-md-4 col-lg-4 image-block full-width mb-4">
 
    <div class="rank-post-content card card-body h-100">
		<div class="<?php post_class(); ?> ">
 	<!-- Display the Title as a link to the Post's permalink. -->
 	<div class="image-block-inner">
      <?php if ( has_post_thumbnail() ) {
        the_post_thumbnail( 'themework-post-image-size' );
       }
        else {
            echo '<img src="' . get_stylesheet_directory_uri() 
                . '/assets/images/not-found.png" />';
        }
        ?>
    </div>
 	<h3 class="rk-post-heading h3 mt-1"><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>

 	<!-- Display the date (November 16th, 2022 format) and a link to other posts by this posts author. -->

 	<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar-check" viewBox="0 0 16 16">
						  <path d="M10.854 7.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 9.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
						  <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5zM1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4H1z"/> <small> <?php the_time('F jS, Y'); ?> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">
						  <path d="M6 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H1s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C9.516 10.68 8.289 10 6 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
						  <path fill-rule="evenodd" d="M15.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 0 1 .708-.708L12.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z"/>
						</svg> by <?php the_author_posts_link(); ?></small>


 	<!-- Display the Post's content in a div box. -->

 	<div class="entry">
 		<?php   echo wp_trim_words( get_the_content(), 40, '...' ); // the_content(); ?>
 	</div>

 	<!-- Display a comma separated list of the Post's Categories. -->

 	<p class="postmetadata"><?php echo( 'Posted in' ); ?> <?php the_category( ', ' ); ?></p>
 	</div> <!-- closes the first div box -->
   </div>
</div>
 	<!-- Stop The Loop (but note the "else:" - see next line). -->
 <?php endwhile;  ?>
<div class="text-center pt-4 pb-2">
    <div class="pagination ranking-pg">
	<?php
	 the_posts_pagination( array(
	    'prev_text' => __( 'Prev', 'themework' ),
	    'next_text' => __( 'Next', 'themework' ),
	) ); ?>
  </div>
</div>
<!--  <div class="nav-previous alignleft"><?php // previous_posts_link( 'Older posts' ); ?></div>
<div class="nav-next alignright"><?php // next_posts_link( 'Newer posts' ); ?></div> -->
<?php else : ?>

 	<!-- The very first "if" tested to see if there were any Posts to -->
 	<!-- display.  This "else" part tells what do if there weren't any. -->
 	<p><?php echo( 'Sorry, no posts matched your criteria.' ); ?></p>

 	<!-- REALLY stop The Loop. -->
 <?php endif; ?>
</div>
</div>
</section>
<?php get_footer(); ?>