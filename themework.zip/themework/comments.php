<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
} ?>

<div class="themework-comments">
    
    <?php wp_list_comments(); 
		paginate_comments_links( array(
		    'prev_text'  => 'back',
		    'next_text' => 'forward'
		) );
    ?>
</div>
