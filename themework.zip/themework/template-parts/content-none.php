<?php if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
} ?>

<article class="no-results">

  <header class="entry-header">
    <h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'themework' ); ?></h1>
  </header>
  <div class="entry-content">
    <p><?php esc_html_e( 'It looks like nothing was found at this location.', 'themework' ); ?></p>
  </div>

</article>