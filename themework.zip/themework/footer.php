<?php 
/**
 * The template for displaying the footer.
 *
 * @package themework
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
</main>
<!-- **************** MAIN CONTENT END **************** -->

<!-- =======================
Footer START -->
<!-- Footer -->
<footer class="text-center text-lg-start bg-light text-muted ranking-footer pt-3">
  <!-- Section: Links  --> 
  <section class="footerblock2">
    <div class="container text-center text-md-start mt-5">
      <!-- Grid row -->
      <div class="row mt-3">
        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <!-- Content -->
          <?php if ( is_active_sidebar( 'sidebar-1' ) ) { ?>
            <div class="sidebar">
                <?php dynamic_sidebar('sidebar-1' ); ?>
            </div>
        <?php } ?>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
         <?php if ( is_active_sidebar( 'sidebar-2' ) ) { ?>
            <div class="sidebar">
                <?php dynamic_sidebar('sidebar-2' ); ?>
            </div>
        <?php } ?>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
         <?php if ( is_active_sidebar( 'sidebar-3' ) ) { ?>
            <div class="sidebar">
                <?php dynamic_sidebar('sidebar-3' ); ?>
            </div>
        <?php } ?>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <!-- Links -->
          <?php if ( is_active_sidebar( 'sidebar-4' ) ) { ?>
            <div class="sidebar">
                <?php dynamic_sidebar('sidebar-4' ); ?>
            </div>
          <?php } ?>
         
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </section>
  <!-- Section: Links  -->

  <!-- Copyright -->
  <div class="text-center p-4" style="background-color: rgb(13 18 103);">
   <div class="site-info">
      <a class="text-white text-decoration-none" href="<?php echo esc_url( __( 'https://rankwebdevelopers.com/', 'themework' ) ); ?>">
        <?php
        /* translators: %s: CMS name, i.e. WordPress. */
        printf( esc_html__( 'Themework Theme by %s', 'themework' ), 'Rishikesh Singh' );
        ?>
      </a>
    </div><!-- .site-info -->
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->
<?php wp_footer(); ?>
</body>
</html>