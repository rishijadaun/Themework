=== Themework ===
Contributors: xolodevelopers
Donate link: https://rankwebdevelopers.com/
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: seo, right-sidebar, left-sidebar, footer-widgets, blog, full-width-template, custom-background, custom-menu, sticky-post, threaded-comments, rtl-language-support, featured-images
Requires at least: 5.2
Tested up to: 5.9
Stable tag: 1.0.0

Themework is a lightweight WordPress theme  - for IT Solutions, SEO Agency and Services Company built with a focus on speed, SEO and usability.

== Description ==

Themework is a lightweight WordPress theme built with a focus on speed and usability. Performance is important to us, which is why a fresh GeneratePress install adds less than 10kb (gzipped) to your page size.


Themework is fully responsive, uses valid HTML/CSS, Bootstrap 


Learn more and check out our [powerful support](https://www.rankwebdevelopers.com).

== Installation ==

= From within WordPress =
1. Visit "Appearance > Themes > Add New"
1. Search for "Themework"
1. Install and activate

== Frequently Asked Questions ==

= Is Themework Free? =
Yes! Themework is a free theme, and always will be.

= Do you offer support? =
Definitely. We offer support for the free theme in the [WordPress.org forums](https://wordpress.org/support/theme/themework).

= Where can I find the theme options? =
All of our options can be found in the Customizer in 'Appearance > Customize'.

= Does Themework have any widget areas? =
GeneratePress has up to 4 widget areas which you can add widgets to in Appearance > Widgets.

= How can I make my site look like your screenshot? =
If you want to replicate the screenshot you see on WordPress.org, please refer to [this article](https://rankwebdevelopers.com/news/demodata/).

== License ==

Themework WordPress Theme, Copyright 2022.
Themework is licensed under the GNU General Public License v2 or later

More details [here](http://www.gnu.org/licenses/gpl-2.0.html).



= Bootstrap =

By Bootstrap Layout, https://getbootstrap.com/
MIT License: https://getbootstrap.com/docs/4.0/about/license/


== Icofont ==
Use icofont for icon
License :https://icofont.com/license


== Changelog ==

= 1.0.0 =
* Initial release

